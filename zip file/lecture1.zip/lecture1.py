#First python script
#this program display an user address
userName=input('enter your first and last name: ')
print('Hello',userName,'!')
userAddress1=input('enter your address 1: ')
userApt=input('enter your apartment number: ')
userCity=input('enter your city: ')
userState=input('enter your state abbreviation: ')
userZip=input('enter your zip code: ')
#Display user address
print('your entered:',userName)
print(userAddress1)
print('Apt',userApt)
print(userCity,(','), userState,userZip)
